# AEGIS — Phased MVP Completion Roadmap

**Date**: November 1, 2026  
**Auditor & Lead Architect**: Antigravity  
**Goal**: Transition Aegis from its current in-memory prototype into a fully functional, tamper-resistant, persistent Zero Trust MVP.

---

## Roadmap Overview

```mermaid
flowchart TD
    P0["Phase 0: Repository Audit & Verification (DONE)"] --> P1["Phase 1: Persistence Layer Migration (MongoDB)"]
    P1 --> P2["Phase 2: Blockchain Client Hardening & Audit Contract"]
    P2 --> P3["Phase 3: Blockchain Event Listeners & State Sync"]
    P3 --> P4["Phase 4: Merkle Tree Generation & Audit Anchoring"]
    P4 --> P5["Phase 5: Context-Aware Zero Trust Authorization"]
    P5 --> P6["Phase 6: End-to-End Integration, UI Proofs & Verification"]
```

---

## Phase 1: Persistence Layer Migration (MongoDB)

### Objective
Replace all volatile in-memory collections (`Map` and array stores) with durable MongoDB schemas and Mongoose models without altering existing service API contracts or breaking frontend workflows.

### Tasks
1. **Schema Definitions** (`backend/src/models/`):
   - `IdentityModel`: Expand existing schema with proper indexes on `walletAddress` (unique) and `roles`.
   - `SessionModel`: Fields `sessionId`, `identityId`, `deviceId`, `tokenHash` (indexed), `expiresAt` (TTL index), `status`, `createdAt`, `revokedAt`.
   - `ChallengeModel`: Fields `nonce` (unique index), `walletAddress`, `issuedAt`, `expiresAt` (TTL index), `used`, `usedAt`.
   - `DeviceModel`: Fields `deviceId` (unique index), `identityId` (indexed), `name`, `fingerprint` (compound index with identity), `status`, `createdAt`, `lastSeenAt`, `revokedAt`.
   - `PolicyModel`: Fields `role` (unique index), `permissions` (`[String]`), `updatedAt`.
   - `AuditEventModel`: Fields `eventId` (unique index), `timestamp` (indexed), `eventType` (indexed), `identityId`, `resource`, `action`, `outcome` (indexed), `reason`, `actor`.
2. **Service Layer Refactoring**:
   - Refactor `identity.service.ts` to perform Mongoose queries.
   - Refactor `session.service.ts` to perform atomic database operations.
   - Refactor `challengeStore.ts` to query and mark nonces atomically in MongoDB.
   - Refactor `device.service.ts` to persist hardware records and last-seen telemetry in MongoDB.
   - Refactor `authorization.service.ts` to read and modify role permissions in `PolicyModel` with fallback to default permissions.
   - Refactor `audit.service.ts` to append logs directly to `AuditEventModel`.
3. **Database Indexing & Bootstrap**:
   - Ensure `server.ts` bootstraps initial admin and default policies into MongoDB upon startup if database is empty.
4. **Verification & Testing**:
   - Run backend test suite.
   - Verify server restart preserves registered identities, devices, active sessions, and audit entries.

---

## Phase 2: Blockchain Client Hardening & Audit Contract

### Objective
Resolve configuration and type defects in the blockchain integration layer and implement the smart contract required for audit anchoring.

### Tasks
1. **Blockchain Configuration Bug Fix** (`backend/src/blockchain/config.ts`):
   - Replace `.some()` check in `hasBlockchainConfiguration` with an explicit check requiring all essential parameters (`RPC_URL`, `CHAIN_ID`, and registry addresses) before marking blockchain writes enabled.
   - When parameters are unconfigured or incomplete, gracefully bypass on-chain writes instead of throwing 503 errors on normal operations.
2. **Device ID Format Normalization** (`backend/src/blockchain/client.ts`):
   - In `client.revokeDevice(deviceId)`, accept either a 32-byte hex string or derive a deterministic 32-byte hash from UUIDs (`keccak256(toUtf8Bytes(deviceId))`) to avoid `requireBytes32` runtime exceptions.
3. **Smart Contract Extension** (`contracts/contracts/AuditRegistry.sol`):
   - Create `AuditRegistry.sol` using OpenZeppelin `AccessControl` (`AUDIT_ADMIN_ROLE`).
   - Implement `anchorAuditRoot(bytes32 rootHash, uint256 batchSize, uint256 startTimestamp, uint256 endTimestamp)` returning `uint256 batchId`.
   - Emit `AuditBatchAnchored(uint256 indexed batchId, bytes32 indexed rootHash, uint256 batchSize, uint256 timestamp)`.
   - Expose `getBatch(uint256 batchId)` and `verifyProof(bytes32 rootHash, bytes32 leafHash, bytes32[] calldata proof)` helper.
4. **Deploy Script Automation** (`contracts/scripts/deploy.ts`):
   - Deploy `AuditRegistry.sol`.
   - Export deployed addresses automatically into `contracts/deployed-addresses.json` and optionally sync them into backend environment config.
5. **Contract Unit Tests**:
   - Add comprehensive tests in `contracts/test/AuditRegistry.test.ts`.

---

## Phase 3: Blockchain Event Listeners & Trusted State Synchronization

### Objective
Enable bidirectional synchronization between Ethereum smart contracts and off-chain backend state.

### Tasks
1. **Sync Cursor Model** (`backend/src/models/SyncState.ts`):
   - Create schema storing `lastProcessedBlock`, `lastSyncTimestamp`, and contract addresses.
2. **Event Listener Service** (`backend/src/services/blockchain/sync.service.ts`):
   - Connect to ethers contract instances with active provider.
   - Subscribe to events:
     - `IdentityRegistry`: `IdentityRegistered`, `IdentityActivated`, `IdentityRevoked`.
     - `PolicyRegistry`: `RoleAssigned`, `RoleRemoved`, `PermissionGranted`, `PermissionRevoked`.
     - `RevocationRegistry`: `IdentityRevoked`, `DeviceRevoked`, `PermissionRevoked`.
     - `AuditRegistry`: `AuditBatchAnchored`.
3. **Block Catch-Up & Historical Replay**:
   - On startup, read `lastProcessedBlock` and scan missed block ranges (`queryFilter`).
   - Process events sequentially and update local MongoDB state/cache.
4. **Reconciliation Worker**:
   - Periodic reconciliation job comparing local identity and revocation statuses with on-chain view functions (`isIdentityRevoked`, `isDeviceRevoked`, `isActive`).
   - Alert and record audit events for any detected tampering or discrepancies.

---

## Phase 4: Merkle Tree Generation & Audit Anchoring

### Objective
Implement cryptographic integrity anchoring for security audit events, ensuring all logged actions are tamper-evident.

### Tasks
1. **Merkle Tree Utility** (`backend/src/utils/merkle.ts`):
   - Implement standard Merkle tree calculation using Keccak-256 (or SHA-256).
   - Generate inclusion proofs (`getProof(leaf)`) and proof validation (`verifyProof(leaf, proof, root)`).
2. **Audit Batching & Anchoring Job** (`backend/src/services/audit/anchoring.service.ts`):
   - Group unanchored audit events from `AuditEventModel` (e.g. every 50 events or every 10 minutes).
   - Leaf formatting: `keccak256(toUtf8Bytes(JSON.stringify({ eventId, timestamp, eventType, identityId, outcome })))`.
   - Compute Merkle root.
   - Submit `AuditRegistry.anchorAuditRoot` transaction via `submitBlockchainWrite`.
   - Persist batch details in `AuditBatchModel` with `rootHash`, `txHash`, `blockNumber`, and event ID ranges.
   - Mark audit event records with `batchId` and `leafIndex`.
3. **Audit Verification APIs**:
   - `GET /api/audit/batches`: List anchored audit batches with block numbers and transaction hashes.
   - `GET /api/audit/:eventId/proof`: Generate Merkle inclusion proof for a specific audit event.
   - `POST /api/audit/verify-proof`: Verify an event against an anchored Merkle root on-chain.

---

## Phase 5: Zero Trust Engine & Context-Aware Authorization

### Objective
Advance from purely role-based access control to true Zero Trust authorization incorporating contextual attributes and verified device trust.

### Tasks
1. **Context Extraction Middleware** (`backend/src/middleware/context.ts`):
   - Capture client IP address, user-agent fingerprint, session recency, and request rate.
2. **Context-Aware Evaluation** (`backend/src/services/authorization/authorization.service.ts`):
   - Evaluate multi-dimensional policy rules:
     - Authenticated Session Status.
     - Identity Lifecycle Status (Local + Synced On-Chain Status).
     - Hardware Device Posture (Active, bound, recent heartbeat within threshold).
     - RBAC Permissions (`resource:action`).
     - Network & Context Bounds (Reject access if device was seen from conflicting IP or revoked).
3. **Emergency Revocation Fast-Path**:
   - If a device or identity is flagged as revoked in the synced revocation cache, terminate all active sessions immediately.

---

## Phase 6: End-to-End Integration, UI Proofs & Verification

### Objective
Expose verification features in the frontend, conduct comprehensive end-to-end integration tests, and produce complete final documentation.

### Tasks
1. **Frontend Audit Verification UI** (`frontend/src/pages/AuditPage.tsx`):
   - Add an "On-Chain Audit Anchors" view displaying batch roots, block heights, and etherscan/explorer transaction links.
   - Add a "Verify Log Integrity" button next to audit rows that fetches the Merkle proof and displays a verified badge.
2. **End-to-End Automated Integration Test Suite**:
   - Spin up Hardhat node, MongoDB, backend, and simulated frontend client.
   - Execute complete flow:
     1. Admin registers new identity.
     2. Wallet connects, receives nonce, signs EIP-191 challenge, logs in.
     3. User enrolls hardware device and verifies binding posture.
     4. User queries protected corporate resources (Employee, Reports, Payroll) with allowed/denied assertions.
     5. Admin modifies policy; verify immediate policy enforcement.
     6. Device is revoked; verify immediate access blockage.
     7. Audit events batch, compute Merkle root, anchor on-chain, and prove log integrity.
3. **Documentation Finalization**:
   - Update `README.md`, `docs/architecture.md`, `docs/api.md`, `docs/security.md`, and `docs/demo-flow.md`.

